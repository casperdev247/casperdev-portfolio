# crc
A template for Covet the redeemer college
